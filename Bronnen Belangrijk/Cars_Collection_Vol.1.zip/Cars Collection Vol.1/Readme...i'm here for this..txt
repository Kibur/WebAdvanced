Cars sprite collection vol.1                                       

This collection contain 14 types of various cars: Audi,Mazda,Chevrolet and Volkswagen.
All cars are in .PNG format and can be modified as you like for type and color.
Every car have a diffuse sprite and a shadow sprite separately,for a total of 28 sprite.
In this way you can place the shadow were you want.
It�s free to use  for non-commercial project.

Enjoy it!

For more collection please visit www.gamemakerfoundry.com

Created by Fabio Monzani